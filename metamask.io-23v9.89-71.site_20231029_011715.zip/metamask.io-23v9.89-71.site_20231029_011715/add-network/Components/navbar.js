function openSelect(){
    document.querySelector(".selectNav").style="left: -20px"
}
function closeSelect(){
    document.querySelector(".selectNav").style="left: -999rem"
}


let pathname = window.location.pathname

document.getElementById("navbar").innerHTML=`



<div class="navbar">
            <ul class="linksNav">
                <li onmouseenter="openSelect()" onmouseleave="closeSelect()">
                    <p>Как пользоваться 
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                        <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                        </path>
                        </svg>
                    </p>
                </li>
                <li>
                    <a href="../../faq/">Помощь</a>
                </li>
                <li>
                    <a class="logo" href="/">
                        <img width="45" height="42" src="/assets/Logos/cropped-метамаск-логотип-45x42.png" alt="Logo">
                        <p>METAMASK</p>
                    </a>
                </li>
                <li>
                <a href="../../swap">Своп</a>
                </li>
                <li>
                <a href="../../token">Токен</a>
                </li>
                <li>
                    <a href="../../reviews">Отзывы</a>
                </li>
                <li class="btn-download">
                <a href="https://metamask.io/" >Скачать</a>
                </li>

                <li>
                <a href="../../en${pathname}"><img src="/assets/images/gb.png" alt="flag"></a>
                </li>
                
                <div onmouseenter="openSelect()" onmouseleave="closeSelect()" class="selectNav">
                   <ul>
                       <li>
                        <a href="../../install/">Установить</a>
                       </li>
                       <li>
                        <a href="../../create/">Создать</a>
                       </li>
                       <li>
                        <a href="../../import/">Импортировать</a>
                       </li>
                       <li>
                        <a href="../../settings/">Настроить</a>
                       </li>
                       <li>
                         <a href="../../add-network/">Добавить сеть</a>
                       </li>
                       <li>
                    <a href="../../add-token/">Добавить токен</a>
                       </li>
                       <li>
                    <a href="../../replenishment/">Пополнить</a>
                       </li>
                       <li>
                    <a href="../../connection/">Подключить</a>
                       </li>
                       <li>
                    <a href="../../commisions/">Комиссия</a>
                       </li>
                       <li>
                    <a href="../../withdrawal/">Вывести</a>
                       </li>
                   </ul> 
                    
                    
                </div>

            </ul>
        </div>

        <div class="logoBurgerMenu ">
        <a class="logo" href="/">
            <img width="45" height="42" src="/assets/Logos/cropped-метамаск-логотип-45x42.png" alt="Logo">
            <p>METAMASK</p>
        </a>
           <div id="burgerMenu" onclick="burger()" class="BurgerMenu">
            <span></span>
            <span></span>
            <span></span>   
        </div>
    </div>
    <div id="accordionNav" class="accordionNav ">
        <a onclick="accordInsdide()" href="#">Как пользоваться
             <span>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                 <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                 </path>
                </svg>
            </span> 
        </a>

        <span id="accordionInside" class="accordionInside">
            <a href="../../install/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Установить
            </a>
            <a href="../../create/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Создать
            </a>
            </a>
            <a href="../../import/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Импортировать
            </a>
            <a href="../../settings/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Настроить
            </a>
            <a href="../../add-network/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Добавить сеть
            </a>
            <a href="../../add-token/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Добавить токен
            </a>
            <a href="../../replenishment/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Пополнить
            </a>
            <a href="../../connection/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Подключить
            </a>
            <a href="../../commisions/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Комиссия
            </a>
            <a href="../../withdrawal/">
                <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="26px" height="16.043px" viewBox="57 35.171 26 16.043" enable-background="new 57 35.171 26 16.043" xml:space="preserve">
                    <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z">
                    </path>
                </svg></span>

                Вывести
            </a>
            
         </span>

        <a href="../../faq/">Помощь</a>
        <a href="../../swap/">Своп</a>
        <a href="../../token/">Токен</a>
        <a href="../../reviews/">Отзывы</a>
        <a href="https://metamask.io/">Скачать</a>
        <a href="../../en${pathname}"><img src="/assets/images/gb.png" alt="No photo"></a>
    </div>
        
`

function burger(){
    document.querySelector("#burgerMenu").classList.toggle("BurgerActive")
    document.querySelector("#accordionNav").classList.toggle("activeAccordionNav")
}
function accordInsdide(){
    document.querySelector("#accordionInside").classList.toggle("activeAccordionInside")
}