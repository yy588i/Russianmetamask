
if (window.clientHeight > 210){
    document.getElementById("btn-to-top").classList.toggle("btn-to-topActive")
}
