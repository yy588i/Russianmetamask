
document.getElementById("footer").innerHTML=`
<div class="footer">
            <div class="ContainerBlock">
                <div class="logoFooter">
                    <img src="/assets/images/логотип-метамаск-кошелька.png" alt="">
                </div>
                <div class="linksFooter">
                    <ul>
                        <li><h2>ИЗУЧАЙТЕ</h2></li>
                        <li><a href="../install/">Установить</a></li>
                        <li><a href="../create/">Создать</a></li>
                        <li><a href="../import/">Импортировать</a></li>
                        <li><a href="../settings/">Настроить</a></li>
                        <li><a href="../add-network/">Добавить сеть</a></li>
                        <li><a href="../add-token/">Добавить токен</a></li>
                        <li><a href="../replenishment/">Пополнение</a></li>
                        <li><a href="../connection/">Подключить</a></li>
                        <li><a href="../commisions/">Комиссия</a></li>
                        <li><a href="../withdrawal/">Вывести</a></li>
                    </ul>
                    <ul>
                        <li><h2>УЧАСТВУЙТЕ</h2></li>
                        <li><a target="_blank" href="https://metamask.io/download/" rel="nofollow noindex noreferrer">Официальный сайт</a></li>
                        <li><a target="_blank" href="https://github.com/MetaMask/metamask-extension">Github</a></li>
                        <li><a target="_blank" href="https://gitcoin.co/metamask/">Gitcoin</a></li>
                        <li><a target="_blank" href="https://consensys.net/open-roles/?discipline=32543">Открытые вопросы</a></li>
                        <li><a target="_blank" href="https://shop.spreadshirt.com/metamask/">Магазин атрибутики</a></li>
                        <li><a target="_blank" href="https://metamask.zendesk.com/hc/en-us/requests/new?ticket_form_id=360001539191">Сотрудничество</a></li>
                    </ul>
                    <ul>
                        <li><h2>ОБЩАЙТЕСЬ</h2></li>
                        <li><a target="_blank" href="https://community.metamask.io/">Помощь</a></li>
                        <li><a target="_blank" href="https://medium.com/metamask">Блог</a></li>
                        <li><a target="_blank" href="https://twitter.com/metamask">Twitter</a></li>
                        <li><a target="_blank" href="https://www.reddit.com/r/Metamask/">Reddit</a></li>
                    </ul>
                    <ul>
                        <li><h2>СОГЛАШЕНИЕ</h2></li>
                        <li><a target="_blank" href="https://consensys.net/privacy-policy/">Политика конфиденциальности</a></li>
                        <li><a target="_blank" href="https://consensys.net/terms-of-use/">Условия использования</a></li>
                        <li><a target="_blank" href="https://metamask.io/cla.html">Лицензионное соглашение с контрибьюторами</a></li>
                    </ul>
                    
                </div>
                <div class="copyRights">
                    <p>©2023 MetaMask • Подробные инструкции по использованию криптокошелька на русском языке.</p>
                </div>
            </div>

        </div>
`